package com.vandana.mvcexample;

public interface LoginResultInterface {
     void onLoginResult(Boolean result, int code);
}
